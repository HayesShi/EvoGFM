"""Print-width figures generated only from the matched records in paired_data.json."""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch

here=Path(__file__).resolve().parent
out=here/"assets"
out.mkdir(exist_ok=True)
data=json.loads((here/"paired_data.json").read_text())
names={"bitcoin-alpha":"BA","bitcoin-otc":"BO","uci":"UCI","wikipedia":"WK","reddit-body":"RB","reddit-title":"RT","superuser":"SU","wiki-talk":"WT","stack-overflow":"SO"}
plt.rcParams.update({"font.family":"STIXGeneral","font.size":7,"axes.linewidth":.45,"pdf.fonttype":42,"hatch.linewidth":.38})
outline="#233744"
def export(fig,name):
    fig.savefig(out/(name+".pdf"))
    fig.savefig(out/(name+".png"),dpi=280)
    plt.close(fig)

def clean(ax):
    ax.spines[["top","right"]].set_visible(False)
    ax.tick_params(width=.45,length=2,pad=1.2,labelsize=6.3)

def table(ax,groups,headers,rows,widths):
    ax.axis("off");ax.set(xlim=(0,1),ylim=(0,1))
    boundaries=np.r_[0,np.cumsum(widths)/sum(widths)]
    middle=(boundaries[1:]+boundaries[:-1])/2
    heights=len(rows)+2
    def y(row):return 1-(row+.50)/heights
    for label,start,end in groups:
        ax.text((boundaries[start]+boundaries[end])/2,y(0),label,va="center",ha="center",fontsize=6.6,fontweight="bold")
        ax.hlines(1-1/heights,boundaries[start]+.008,boundaries[end]-.008,lw=.32,color=outline)
        if start:ax.vlines(boundaries[start],.015,1-1/heights,lw=.33,color=outline)
    for i,values in enumerate([headers]+rows,1):
        for x,label in zip(middle,values):
            ax.text(x,y(i),label,ha="center",va="center",fontsize=6.55,fontweight="bold" if i==1 else "normal")
    ax.hlines([.012,1-2/heights,.995],0,1,lw=[.53,.38,.55],color=outline)

def updates(mode):
    selected = [r for r in data["updates"] if r["mode"] == mode]
    graphs = list(dict.fromkeys(r["graph"] for r in selected))
    fig = plt.figure(figsize=(3.5, 2.08))
    title = {"insert": "Cost of inserting edges", "window": "Cost of sliding-window updates"}[mode]
    fig.text(.008, .991, title, fontsize=8.8, fontweight="bold", va="top")
    series = [
        ("Rescan (s)", "#e0e9f4", "#314f78", "////"),
        ("Incremental (s)", "#54a8d4", "#244b66", ""),
        ("History (ms)", "#fdf0dc", "#ae630a", "///"),
        ("Topology (ms)", "#e3f2eb", "#117451", "xxx"),
    ]
    handles = [Patch(facecolor=face, edgecolor=edge, hatch=hatch, linewidth=.4)
               for _, face, edge, hatch in series]
    fig.legend(handles, [v[0] for v in series], loc="upper center", bbox_to_anchor=(.5, .919),
               ncols=4, frameon=False, fontsize=6.35, handlelength=1.0, columnspacing=.85,
               handletextpad=.25, borderaxespad=0)
    gs = fig.add_gridspec(1, len(graphs), left=.067, right=.939, bottom=.40, top=.773,
                          wspace=.54, width_ratios=[4 if g != "stack-overflow" else 1.45 for g in graphs])
    offsets = np.array([-.30, -.12, .14, .32])
    # At every tick, 1 s on the left aligns with 10 ms on the right.
    ticks = {"insert":{"superuser":.25,"wiki-talk":1.0,"stack-overflow":10.0},
             "window":{"superuser":.20,"wiki-talk":.75}}
    rows = []
    for j, graph in enumerate(graphs):
        ax = fig.add_subplot(gs[j])
        cases = [r for r in selected if r["graph"] == graph]
        ingest_axis = ax.twinx()
        step = ticks[mode][graph]
        ax.set_ylim(0, 3*step)
        ingest_axis.set_ylim(0, 30*step)
        tick_values = np.arange(4)*step
        ax.set_yticks(tick_values, [f"{v:g}" for v in tick_values])
        ingest_axis.set_yticks(tick_values*10, [f"{v*10:g}" for v in tick_values])
        ingest_axis.spines[["left","top","bottom"]].set_visible(False)
        ingest_axis.spines["right"].set_color("#53625c")
        ingest_axis.tick_params(axis="y",colors="#44564d",length=1.5,pad=1.1,width=.4,labelsize=5.65)
        ingest_axis.patch.set_visible(False)
        for i, record in enumerate(cases):
            stages = np.asarray(record["stages"])
            rescan, inc = np.median(stages.sum(axis=2), axis=1)
            history, topology = np.median(stages[1, :, [2, 1]], axis=1)
            values = [rescan, inc, history*1000, topology*1000]
            for k,(x,v,(_,face,edge,hatch)) in enumerate(zip(i+offsets,values,series)):
                axis = ax if k<2 else ingest_axis
                assert 0 < v < axis.get_ylim()[1]
                axis.bar(x,v,width=.145,color=face,edgecolor=edge,hatch=hatch,linewidth=.45,zorder=2)
            # Label small history medians in ms; their physical heights stay proportional.
            ingest_axis.annotate(f"{history*1000:.2f}",(i+offsets[2],history*1000),
                                 xytext=(0,1.0),textcoords="offset points",ha="center",va="bottom",
                                 rotation=90,fontsize=4.9,color="#814704")
            x1,x2=i+offsets[:2]
            y=rescan+.05*step
            ax.plot([x1,x1,x2,x2],[y,y+.06*step,y+.06*step,y],color=outline,lw=.42)
            ax.annotate(f"{rescan/inc:.2f}×",((x1+x2)/2,y+.06*step),
                        xytext=(0,.65),textcoords="offset points",ha="center",va="bottom",
                        fontsize=5.65,fontweight="bold")
            if record["batch"] == 1:
                means=stages.mean(axis=1)
                rows.append([names[graph], f"{rescan:.2f}", f"{inc:.2f}", f"{rescan/inc:.2f}×",
                             f"{means[0,0]:.2f}", f"{means[1,0]:.2f}",
                             f"{means[0,1:].sum()*1000:.1f}", f"{means[1,1:].sum()*1000:.1f}"])
        ax.set_xlim(-.75,len(cases)-.47)
        ax.set_xticks(range(len(cases)),[str(r["batch"]) if r["batch"]<1000 else "4k" for r in cases])
        ax.set_title({"superuser":"SuperUser","wiki-talk":"Wiki-Talk","stack-overflow":"SO"}[graph],fontsize=7.1,pad=.4)
        ax.grid(axis="y", color="#cbd2d5",linestyle=":",linewidth=.35,zorder=0)

        clean(ax)
        ax.tick_params(axis="y",labelsize=5.65,pad=1)
    fig.text(.53,.306,"Edited edges per commit",ha="center",fontsize=6.4)
    t=fig.add_axes([.008,.062,.984,.224])
    table(t,[("One edit",0,1),("Median commit (s)",1,4),("Mean executor (s)",4,6),("Mean ingest (ms)",6,8)],
          ["Graph","Scan","Inc.","Ratio","Scan","Inc.","Scan","Inc."],rows,[.83,1,1,1.1,1,1,1,1])
    fig.text(.008,.012,"Left axis: commit (s). Right axis: incremental ingest (ms). Eight commits.",fontsize=6.3)
    export(fig, "paired_"+mode)

def sharing():
    fig=plt.figure(figsize=(3.5,1.67))
    fig.text(.008,.985,"Work and time on identical query traces",va="top",fontsize=8.8,fontweight="bold")
    ax=fig.add_axes([.09,.27,.32,.51])
    rows=[]
    for i,r in enumerate(data["sharing"]):
        hf,own=r["runs"]
        counts=np.array([hf["base_dot_products"],own["base_dot_products"]])/1e6
        ax.bar([i-.17,i+.17],counts,.32,color=["#d8dce1","#77accb"],edgecolor=outline,lw=.45)
        ax.text(i+.17,counts[1]+.8,f"{counts[0]/counts[1]:.2f}×",ha="center",fontsize=6.4)
        rows.append([names[r["graph"]],*[f"{v['total_s']:.2f}" for v in (hf,own)],*[f"{v['query_p99_ms']:,.0f}" for v in (hf,own)]])
    ax.set_xticks([0,1],["SU","WT"]);ax.set_ylim(0,36);ax.set_ylabel("Base scores (M)",labelpad=.8,fontsize=6.7);clean(ax)
    fig.legend([Patch(facecolor=c,edgecolor=outline,lw=.4) for c in ["#d8dce1","#77accb"]],["HF","Ours"],loc="upper left",bbox_to_anchor=(.055,.868),frameon=False,ncols=2,fontsize=6.1,borderaxespad=0,columnspacing=.7,handlelength=1.1,handletextpad=.25)
    table(fig.add_axes([.442,.34,.551,.40]),[("",0,1),("Trace time (s)",1,3),("P99 (ms)",3,5)],["Graph","HF","Ours","HF","Ours"],rows,[1,1,1,1,1.1])
    fig.text(.008,.12,"Each trace scores 65,536 candidate pairs. Labels give Head-fused (HF)",fontsize=6.5)
    fig.text(.008,.044,"score evaluations divided by Ours. Times include instrumentation.",fontsize=6.5)
    export(fig,"paired_sharing")

def replay():
    fig=plt.figure(figsize=(3.5,1.92))
    fig.text(.008,.985,"End-to-end cost on native traces",va="top",fontsize=8.8,fontweight="bold")
    ax=fig.add_axes([.125,.254,.26,.4822])
    ax.axvline(1,color="#777777",lw=.6,ls=":")
    rows=[]
    for i,r in enumerate(data["native"]):
        hf,own=r["runs"]
        speed=hf["total_s"]/own["total_s"]
        ax.plot([1,speed],[i,i],color="#507389",lw=1.15)
        ax.plot(speed,i,"o",color="#477e9d",ms=3.0)
        ax.annotate(f"{speed:.2f}×",(speed,i),xytext=(3,0),textcoords="offset points",va="center",fontsize=6.1)
        rows.append([names[r["graph"]],f"{hf['total_s']:,.2f}",f"{own['total_s']:,.2f}",f"{hf['query_p99_ms']:,.0f}",f"{own['query_p99_ms']:,.0f}"])
    ax.set_xlim(.91,1.64);ax.set_xticks([1,1.2,1.4]);ax.set_ylim(len(rows)-.5,-.5);ax.set_yticks(range(len(rows)),[r[0] for r in rows]);ax.set_xlabel("HF / Ours",fontsize=6.5,labelpad=1);clean(ax)
    table(fig.add_axes([.42,.254,.575,.62]),[("",0,1),("Total time (s)",1,3),("P99 (ms)",3,5)],["Graph","HF","Ours","HF","Ours"],rows,[.85,1.5,1.5,1.04,1.04])
    fig.text(.008,.105,"One complete replay per executor; all seven graphs with matched runs.",fontsize=6.4)
    fig.text(.008,.035,"FP32 differences on RT and WT are detailed in the fidelity table.",fontsize=6.4)
    export(fig,"paired_replay")

if __name__=="__main__":
    updates("insert")
    updates("window")
    sharing()
    replay()
