"""Prepare the page-marked review layout from the existing vector art and run ledger."""
import csv
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator, FuncFormatter
from pypdf import PdfReader, PdfWriter

ROOT = Path(__file__).resolve().parent
ASSETS = ROOT / "assets"
MARKED = ["F1_update", "access_visits", "access_storage", "F5_memory", "F6_trace"]
SIM_COLORS = {(255, 241, 166), (255, 223, 84)}


def clean_figure(name):
    """Drop just the two known provenance overlay paints in these matplotlib vectors."""
    writer = PdfWriter()
    page = writer.add_page(PdfReader(ASSETS / (name + ".pdf")).pages[0])
    stream = page.get_contents()
    active = False
    stack = []
    ops = []
    for args, op in stream.operations:
        if op == b"q":
            stack.append(active)
        elif op == b"Q":
            active = stack.pop()
        elif op == b"rg":
            active = tuple(round(255 * float(i)) for i in args) in SIM_COLORS
        elif op in (b"g", b"k", b"sc", b"scn", b"cs"):
            active = False
        if active and op in (b"f", b"f*", b"B", b"B*", b"b", b"b*"):
            op = b"n"
        ops.append((args, op))
    stream.operations = ops
    page.replace_contents(stream)
    with (ASSETS / (name + "_plain.pdf")).open("wb") as out:
        writer.write(out)


def sensitivity():
    panels = [
        ("commit_s", "", [1, 16, 256, 4096], "Commit (s)", "Inserted edges"),
        ("Total (s)", "Queries / version=", [1, 16, 256, 4096], "Total time (s)", "Queries/version"),
        ("Time / query (s)", "Updates / query=", [.01, .1, 1, 10], "Time/query (s)", "Updates/query"),
        ("Pairs / s", "Candidates=", [16, 64, 256, 1024], "Pairs/s", "Candidates"),
        ("query P99 ms", "cache=", [0, 4, 16, 64, 256], "Query P99 (ms)", "Cache (MiB)"),
    ]
    methods = [("ours_rebuild_moments", "Moment rescan", "#ce9938", "o", (0, (4, 2))),
               ("neutronrt_adapt", "NeutronRT-adapt", "#4298b3", "s", (0, (1.6, 1.4))),
               ("head_fused", "Head-fused", "#4665a1", "^", (0, (3, 1.2, .7, 1.2))),
               ("ours", "Ours", "#b24d32", "D", "-")]
    with (ROOT / "atlas_plot_data.csv").open(encoding="utf-8-sig") as f:
        values = {(r["metric"], r["method"], r["condition"]):float(r["value"])
                  for r in csv.DictReader(f) if r["graph"] == "wiki-talk"}
    plt.rcParams.update({"font.family":"DejaVu Serif","font.size":6.3,"pdf.fonttype":42,
                         "axes.linewidth":.48,"xtick.labelsize":5.6,"ytick.labelsize":5.7})
    fig, axes = plt.subplots(1, 5, figsize=(6.03, 1.16))
    fig.subplots_adjust(left=.045, right=.987, top=.64, bottom=.275, wspace=.43)
    for idx,(ax,(metric,prefix,settings,heading,xlabel)) in enumerate(zip(axes,panels)):
        for method,label,color,marker,linestyle in methods:
            ys = [values[metric,method,prefix+str(x)] for x in settings]
            ax.plot(range(len(settings)),ys,color=color,marker=marker,ms=2.3,lw=.85,
                    linestyle=linestyle,markeredgewidth=.4,label=label,clip_on=False)
        ax.set_xticks(range(len(settings)),[str(x).lstrip("0") if 0<x<1 else str(x) for x in settings])
        ax.set_xlim(-.18,len(settings)-.82)
        ax.set_title(f"({chr(97+idx)}) {heading}",fontsize=6.5,pad=2.5,fontweight="bold")
        ax.set_xlabel(xlabel,fontsize=6.3,labelpad=1.5)
        ax.yaxis.set_major_locator(MaxNLocator(nbins=3))
        ax.yaxis.set_major_formatter(FuncFormatter(lambda v,pos: f"{v/1000:g}k" if abs(v)>=1000 else f"{v:g}"))
        ax.spines[["top","right"]].set_visible(False)
        ax.tick_params(length=2,pad=1.2,width=.45)
        ax.set_axisbelow(True)
        ax.grid(axis="y",color=".87",lw=.35)
    fig.legend(*axes[0].get_legend_handles_labels(),loc="upper center",ncol=4,frameon=False,
               bbox_to_anchor=(.5,1.01),borderaxespad=.05,handlelength=2.3,handletextpad=.4,columnspacing=1.3)
    fig.savefig(ASSETS / "F7_compact.pdf")
    plt.close(fig)


def review_layout(tex):
    for name in MARKED:
        tex = tex.replace("assets/"+name+"}", "assets/"+name+"_plain}")
    tex = tex.replace(r"\cellcolor{sim}#1", "#1").replace("Yellow marks and cells denote simulations. ", "")
    tex = tex.replace(r"\includegraphics[width=\linewidth]{assets/F7_sensitivity}",
                      r"\makebox[\linewidth][c]{\includegraphics[width=6.03in]{assets/F7_compact}}")
    tex = tex.replace("Sensitivity to edit batch, requests per version, update mix, candidate count and cache budget.",
                      "Wiki-Talk sensitivity across five sweeps. Horizontal ticks show the tested settings at equal spacing.")
    return tex


if __name__ == "__main__":
    for name in MARKED:
        clean_figure(name)
    sensitivity()
