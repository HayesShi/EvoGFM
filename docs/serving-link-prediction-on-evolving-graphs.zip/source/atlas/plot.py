"""Build the annotated atlas at its final print dimensions from the saved plot data."""
from pathlib import Path
import csv
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.ticker import NullLocator

out=Path(__file__).resolve().parent
with (out/"revised_data.csv").open(encoding="utf-8-sig") as f:
    values={(r["figure"],r["graph"],r["method"],r["metric"]):(float(r["value"]),r["source"]=="scenario") for r in csv.DictReader(f)}
SU,WT,SO,RT="superuser","wiki-talk","stack-overflow","reddit-title"
H,O,F,N,L="head_fused","ours","full_refresh","neutronrt_adapt","shared_lru"
abbr={SU:"SU",WT:"WT",SO:"SO",RT:"RT"}
# Light fills, fine outlines and hatch directions follow the reference's categorical encoding.
styles={H:("#87c8e9",""),O:("#fffdf7","////"),F:("#dac3e9","...."),N:("#b0dec9","\\\\"),
        L:("#f2d9a2","++"),"ours_feature_layer_one":("#b0dec9","\\\\"),"ours_no_scores":("#dac3e9","....")}
names={H:"Head-fused",O:"Ours",F:"Full refresh",N:"NeutronRT-adapt",L:"Shared-LRU","ours_feature_layer_one":"Feature + L1","ours_no_scores":"No retained scores"}
width=3.46
plt.rcParams.update({"font.family":"DejaVu Serif","font.size":6.6,"axes.labelsize":6.6,"xtick.labelsize":6.2,"ytick.labelsize":6.1,
 "axes.linewidth":.45,"hatch.linewidth":.35,"pdf.fonttype":42,"svg.fonttype":"none"})
def fig(n,h):
    f,axs=plt.subplots(1,n,figsize=(width,h),squeeze=False,layout="constrained")
    f.get_layout_engine().set(w_pad=.018,h_pad=.012,wspace=.025)
    for a in axs.flat:
        a.spines[["top","right"]].set_visible(False);a.tick_params(length=1.8,width=.4,pad=1.3)
    return f,list(axs.flat)
def legend(f,ms,cols):
    f.legend([Patch(facecolor=styles[m][0],hatch=styles[m][1],edgecolor="#364352",lw=.4) for m in ms],
             [names[m] for m in ms],loc="outside upper center",ncols=cols,frameon=False,fontsize=6.1,handlelength=1.25,
             columnspacing=.75,handletextpad=.33,borderaxespad=.05,labelspacing=.18)
def bar(a,x,y,w,m,sim):
    face,hatch=styles[m];a.bar(x,y,w,facecolor=face,hatch=hatch,edgecolor="#344351",linewidth=.45)
def save(f,key):
    for ext in ("pdf","svg"):f.savefig(out/f"{key}.{ext}")
    plt.close(f)
def axis_groups(a,ds):
    a.set_xticks(range(len(ds)),[abbr[d] for d in ds]);a.set_xlim(-.5,len(ds)-.5)

rescan="ours_rebuild_moments"
styles[rescan]=("#d0d5dd","--")
names[rescan]="Moment rescan"
methods=[F,rescan,N,H,L,O]
graphs=[SO,RT,WT]
with (out.parent/"atlas_plot_data.csv").open(encoding="utf-8-sig") as stream:
    inputs={(r["metric"],r["graph"],r["method"],r["condition"]):
            (float(r["value"]),r["source"]=="scenario") for r in csv.DictReader(stream)}

def wide_grid(rows,cols,height):
    f,axs=plt.subplots(rows,cols,squeeze=False,figsize=(7.11,height),layout="constrained")
    f.get_layout_engine().set(w_pad=.029,h_pad=.014,wspace=.015,hspace=.025)
    for a in axs.flat:
        a.spines[["top","right"]].set_visible(False)
        a.tick_params(length=1.8,width=.4,pad=1.1)
    return f,axs

def labeled_bar(a,x,v,m,sim,formatted):
    face,hatch=styles[m]
    a.bar(x,v,.146,facecolor=face,hatch=hatch,edgecolor="#42515d",linewidth=.32,zorder=2)
    annotation=a.annotate(formatted,(x,v),xytext=(0,1.4),textcoords="offset points",
                          rotation=90,ha="center",va="bottom",fontsize=5.25,
                          fontweight="bold" if m==O else "normal",
                          color="#174f65" if m==O else "#273644",zorder=4)

f,axs=wide_grid(1,3,1.32)
legend(f,methods,6)
for a,d,label,initial in zip(axs.flat,graphs,["Stack-Overflow","Reddit-title","Wiki-Talk"],[22713323,179734,2206593]):
    for j,pct in enumerate([.001,.01,.1,1]):
        n=max(1,round(initial*pct/100))
        for i,m in enumerate(methods):
            v,sim=inputs["commit_s",d,m,str(n)]
            labeled_bar(a,j+(i-2.5)*.152,v,m,sim,f"{v:.2f}" if v<1 else f"{v:.1f}")
        if j==1:
            own,sim=inputs["commit_s",d,O,str(n)]
            a.set_title(f"{label}   ·   {n/own:.0f} edges/s" if not sim else label,fontsize=7,pad=2)
            if sim:
                a.set_title(label,loc="left",fontsize=7,pad=2)
                a.set_title(f"{n/own:.0f} edges/s",loc="right",fontsize=6.25,pad=2)
                a.set_title("",loc="center")
    a.set_ylim(0,a.get_ylim()[1]*1.36)
    a.set_xticks(range(4),[".001",".01",".1","1"]);a.set_xlim(-.50,3.50)
axs[0,0].set_ylabel("Commit time (s)")
f.supxlabel("Edges inserted (%)",fontsize=6.5)
save(f,"F1_update")

f,axs=wide_grid(2,2,1.80)
legend(f,methods,6)
for a,metric,tag in zip(axs.flat,["Vertex visits","Edge visits","Feature bytes read","Statistic entries touched"],"abcd"):
    for j,d in enumerate(graphs):
        for i,m in enumerate(methods):
            v,sim=inputs[metric,d,m,"0.01% / full"]
            label=f"{v:.2f}" if v>=.01 else f"{v*1e4:.1f}e-4"
            labeled_bar(a,j+(i-2.5)*.152,v,m,sim,label)
    axis_groups(a,graphs)
    a.set_title(f"({tag}) {metric}",fontsize=6.8,loc="left",pad=1)
    if tag=="d":
        a.set_yscale("log");a.set_ylim(6e-5,90);a.set_yticks([.0001,.01,1]);a.yaxis.set_minor_locator(NullLocator())
    else:
        a.set_ylim(0,1.72);a.set_yticks([0,.5,1])
for a in axs[0]:a.tick_params(labelbottom=False)
f.supylabel("Relative to full refresh",fontsize=6.7)
save(f,"F2_access")

# Embed a second scale for the two short commits in the unused space above them.
def inset_canvas(height, rect, fig_width=2.55):
    f=plt.figure(figsize=(fig_width,height))
    a=f.add_axes(rect)
    return f,a

def fine_axes(a):
    a.spines[["top","right"]].set_visible(False)
    a.tick_params(length=1.7,width=.4,pad=1.1)

f,a=inset_canvas(1.09,[.145,.16,.84,.74],fig_width=2.13)
fine_axes(a)
stages=["Executor update","Topology ingest","History ingest"]
method_fill={rescan:"#468EBB", O:"#E88832"}
method_edge={rescan:"#245777", O:"#A74B12"}
stage_hatch=["","",".."]
datasets=[SU,WT,SO]
totals={}
def draw_commit(ax,j,d,m,shift):
    x=j+shift;bottom=0
    for k,stage in enumerate(stages):
        v=values["F3",d,m,stage][0]
        ax.bar(x,v,.29,bottom=bottom,color=[method_fill[m],"#516371","#D9E1E6"][k],edgecolor=method_edge[m],lw=.32,
               hatch="///" if m==O else stage_hatch[k])
        bottom+=v
    return bottom
for j,d in enumerate(datasets):
    for m,shift in [(rescan,-.17),(O,.17)]:
        v=draw_commit(a,j,d,m,shift);totals[d,m]=v
        if d==SO:
            a.annotate(f"{v:.2f}",(j+shift,v),xytext=(0,1.4),textcoords="offset points",ha="center",fontsize=6)
a.set_xlim(-.55,2.54);a.set_ylim(0,27);a.set_yticks([0,10,20]);a.set_ylabel("Commit (s)",labelpad=.6)
a.set_xticks(range(3),["SU","WT","SO"])
z=a.inset_axes([.09,.42,.55,.51]);fine_axes(z);z.set_facecolor("white");z.set_axisbelow(True);z.grid(axis="y",lw=.35,color="#E4E9EF")
for j,d in enumerate(datasets[:2]):
    for m,shift in [(rescan,-.17),(O,.17)]:
        v=draw_commit(z,j,d,m,shift)
        z.text(j+shift,v+.06,f"{v:.2f}",fontsize=5.4,ha="center")
z.set_xlim(-.59,1.59);z.set_ylim(0,2.85);z.set_yticks([0,2]);z.set_xticks([0,1],["SU","WT"])
z.tick_params(labelsize=5.3,length=1,pad=.2)
a.legend([Patch(fc=method_fill[m],ec=method_edge[m],lw=.4,hatch="///" if m==O else "") for m in [rescan,O]],
         ["Rescan","Incremental"],loc="lower left",bbox_to_anchor=(0,.99),frameon=False,ncols=2,
         borderaxespad=0,borderpad=0,fontsize=6.1,handlelength=1.25,handletextpad=.4,columnspacing=1.15)
save(f,"F3_stages")

# A zero-centred comparison shares one scale across memory pools. Absolute
# cache size has its own embedded scale because the reference cache is zero.
f,a=inset_canvas(1.02,[.15,.20,.835,.69])
fine_axes(a)
pools=[("peak RSS GiB","Host RSS","#58B59B",""),("peak CUDA GiB","GPU","#CC79A7","..")]
for j,d in enumerate([RT,WT,SO]):
    for i,(metric,_,face,hatch) in enumerate(pools):
        base,s0=values["F5",d,H,metric];own,s1=values["F5",d,O,metric]
        delta=100*(own/base-1);x=j+(i-.5)*.28
        a.bar(x,delta,.26,color=face,hatch=hatch,lw=.4,edgecolor="#41433f")
        a.annotate(f"{delta:+.1f}",(x,delta),xytext=(-1 if i==0 else 1,1 if delta>=0 else -1.5),
                   textcoords="offset points",ha="right" if i==0 else "left",va="bottom" if delta>=0 else "top",
                   fontsize=5.5)
a.axhline(0,color="#464b4f",lw=.5)
a.set_xlim(-.56,4.45);a.set_ylim(-23,17);a.set_yticks([-15,0,10])
a.set_xticks(range(3),["RT","WT","SO"]);a.set_ylabel("vs. HF (%)",labelpad=.9)
a.legend([Patch(fc=face,hatch=hatch,ec="#41433f",lw=.4) for _,_,face,hatch in pools],
         ["Host RSS","GPU"],loc="lower left",bbox_to_anchor=(-.01,.99),ncols=2,frameon=False,borderaxespad=0,handlelength=1.15,fontsize=6)
z=a.inset_axes([.65,.15,.335,.71]);fine_axes(z)
for j,d in enumerate([RT,WT,SO]):
    v,sim=values["F5",d,O,"peak shared MiB"]
    z.bar(j,v,.61,fc="#84B7D4",ec="#315B73",lw=.38)
    z.text(j,v+1.5,f"{v:.0f}",ha="center",fontsize=5.4)
z.set_ylim(0,86);z.set_yticks([0,64]);z.set_xticks(range(3),["RT","WT","SO"])
z.tick_params(labelsize=5.5,length=1,pad=.7);z.set_title("Cache (MiB)",fontsize=6,pad=1.4)
save(f,"F5_memory")

f,axs=fig(3,1.75)
# Replace the temporary axes with a short two-row grid so each column keeps its dataset.
for a in axs:a.remove()
gs=f.add_gridspec(2,3,height_ratios=[.94,1.05])
ms=[F,N,H,L,O]
linecolors=["#806392","#397f65","#247fae","#9e732a","#263643"]
from matplotlib.lines import Line2D
from matplotlib.legend_handler import HandlerTuple
order=[0,3,1,4,2]
paired=[(Patch(facecolor=styles[ms[i]][0],hatch=styles[ms[i]][1],edgecolor="#344351",lw=.35),
         Line2D([],[],color=linecolors[i],lw=.65,marker=["s","^","D","v","o"][i],markersize=2.3,mfc="white" if ms[i]==O else linecolors[i])) for i in order]
f.legend(paired,[names[ms[i]] for i in order],handler_map={tuple:HandlerTuple(ndivide=None,pad=.1)},loc="outside upper center",ncols=3,frameon=False,fontsize=6.05,handlelength=1.85,handletextpad=.3,columnspacing=.6,borderaxespad=.05,labelspacing=.18)
for j,(d,lab) in enumerate([(RT,"Reddit-title"),(SU,"SuperUser"),(WT,"Wiki-Talk")]):
    a=f.add_subplot(gs[0,j]);b=f.add_subplot(gs[1,j])
    for ax in (a,b):
        ax.spines[["top","right"]].set_visible(False);ax.tick_params(length=1.7,width=.4,pad=1.1)
    a.set_title(lab,fontsize=6.4,pad=1.5)
    for i,m in enumerate(ms):
        entry=values.get(("F6",d,m,"trace min"))
        if entry:
            v,s=entry;bar(a,i,v,.82,m,s)
        else:a.text(i,.04,"–",transform=a.get_xaxis_transform(),ha="center")
        if ("F6",d,m,"P50 s") in values:
            ys=[values["F6",d,m,k+" s"][0] for k in ["P50","P95","P99"]]
            b.plot(range(3),ys,marker=["s","^","D","v","o"][i],ms=2.6,lw=.85,color=linecolors[i],mec=linecolors[i],mew=.55,
                   mfc="white" if m==O else linecolors[i],ls="--" if m==F else "-")
    a.set_xlim(-.55,4.55);a.set_xticks([]);a.set_yscale("log")
    # Per-graph scales keep the within-graph ordering readable.
    ticks=[[.5,1,2],[4,10,30],[200,500,2000]][j];a.set_yticks(ticks,[str(x) for x in ticks]);a.yaxis.set_minor_locator(NullLocator())
    b.set_xticks(range(3),["50","95","99"]);b.set_yscale("log");ticks=[[.01,.05,.1],[.01,.05,.2],[1,3,7]][j]
    b.set_yticks(ticks,[f"{x:g}" for x in ticks]);b.yaxis.set_minor_locator(NullLocator())
    if j==0:a.set_ylabel("Replay (min)",labelpad=.8);b.set_ylabel("Query (s)",labelpad=.8)
    b.set_xlabel("Percentile",labelpad=1)
save(f,"F6_trace")

from sweeps import plot_sweeps
plot_sweeps(out)
