"""Measured edit dispersion and shared-cache sweeps at publication size."""
import json
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.lines import Line2D
from matplotlib.ticker import MaxNLocator

def plot_sweeps(out):
    rows=json.loads((out/"sweep_inputs.json").read_text())
    runs={(r["dataset"],r["method"],r["condition"]):r for r in rows}
    blue="#D55E00";violet="#168898"
    def style(a):
        a.spines[["top","right"]].set_visible(False)
        a.tick_params(length=1.7,width=.4,pad=1,labelsize=5.7)
        a.grid(axis="y",lw=.3,color="#dce1e7")
        a.set_axisbelow(True)
    def export(f,name):
        for ext in ("pdf","svg"):f.savefig(out/f"{name}.{ext}")
        plt.close(f)

    f,axs=plt.subplots(1,2,figsize=(3.98,1.12))
    f.subplots_adjust(left=.096,right=.995,bottom=.21,top=.76,wspace=.20)
    patterns=[("ours_rebuild_moments","insert","#468EBB",""),("ours_rebuild_moments","window","#84B7D4","///"),
              ("ours","insert","#E88832",""),("ours","window","#F1BB4A","///")]
    f.legend([Patch(fc=c,ec="#424e59",hatch=h,lw=.35) for _,_,c,h in patterns],
             ["Rescan / I","Rescan / W","Ours / I","Ours / W"],loc="upper center",bbox_to_anchor=(.5,1.045),
             ncols=4,frameon=False,fontsize=5.8,handlelength=1.1,handletextpad=.28,columnspacing=.6)
    for a,d,name in zip(axs,["superuser","wiki-talk"],["SuperUser","Wiki-Talk"]):
        style(a);max_y=0
        for j,b in enumerate([1,16,256,4096]):
            for i,(m,typ,c,h) in enumerate(patterns):
                obs=runs[d,m,f"e6_{typ}_{b}"]["samples"]
                q1,med,q3=np.percentile(obs,[25,50,75]);x=j+(i-1.5)*.226
                a.bar(x,med,.215,color=c,edgecolor="#3b4c5b",lw=.35,hatch=h,zorder=2)
                a.errorbar(x,med,yerr=[[med-q1],[q3-med]],lw=.5,capsize=1.2,capthick=.45,color="#222e39",zorder=3)
                a.annotate(f"{med:.2f}",(x,q3),xytext=(0,1.2),textcoords="offset points",rotation=90,
                           ha="center",va="bottom",fontsize=5.3,color="#263544")
                max_y=max(max_y,q3)
        a.set_ylim(0,max_y*1.48);a.yaxis.set_major_locator(MaxNLocator(3));a.set_xlim(-.52,3.52)
        a.set_xticks(range(4),["1","16","256","4k"]);a.set_xlabel("Edited edges",fontsize=6.1,labelpad=0)
        a.set_title(name,fontsize=6.6,fontweight="bold",pad=1)
    axs[0].set_ylabel("Commit (s)",fontsize=6.3,labelpad=.7)
    export(f,"F3_batch_detail")

    # Each data point is one completed run under the indicated byte budget.
    f,ax=plt.subplots(1,4,figsize=(7.12,1.26))
    f.subplots_adjust(left=.053,right=.993,top=.74,bottom=.22,wspace=.31)
    specs=[("peak_rss_bytes",2**30,"Host RSS (GiB)"),("peak_gpu_allocated_bytes",2**30,"GPU peak (GiB)"),
           ("peak_shared_cache_bytes",2**20,"Retained cache (MiB)"),("query_p99_ms",1000,"Query P99 (s)")]
    series=[(d,m,"SU" if d=="superuser" else "WT",c,ls,marker)
            for d,ls in [("superuser","-"),("wiki-talk","--")]
            for m,c,marker in [("shared_lru",violet,"s"),("ours",blue,"o")]]
    f.legend([Line2D([],[],color=c,ls=ls,marker=mk,ms=2.8,lw=.9) for d,m,short,c,ls,mk in series],
             [f"{short} / "+("Ours" if m=="ours" else "Shared-LRU") for d,m,short,c,ls,mk in series],
             loc="upper center",bbox_to_anchor=(.5,1.025),ncols=4,frameon=False,fontsize=6.2,columnspacing=1.5,handlelength=1.7)
    for a,(field,scale,label) in zip(ax,specs):
        style(a)
        for d,m,short,c,ls,mk in series:
            v=[runs[d,m,f"e8_budget_{b}"][field]/scale for b in [0,4,16,64,256]]
            a.plot(range(5),v,color=c,ls=ls,marker=mk,ms=2.8,mfc="white" if ls=="-" else c,lw=1,mew=.65)
            # End labels use separate fixed slots and a leader when endpoints are close.
            a._end_values=getattr(a,"_end_values",[])+[(v[-1],c,ls)]
        a.set_xlim(-.12,5.35);a.set_xticks(range(5),[0,4,16,64,256]);a.set_xlabel("Cache limit (MiB)",fontsize=6.2,labelpad=.45)
        a.set_title(label,loc="left",fontsize=6.7,fontweight="bold",pad=1.2);a.yaxis.set_major_locator(MaxNLocator(3))
        lo,hi=a.get_ylim();span=hi-lo;lo-=.06*span;hi+=.11*span;a.set_ylim(lo,hi)
        endpoints=sorted(a._end_values,key=lambda t:t[0]);sep=(hi-lo)*.15
        slots=[]
        for v,c,ls in endpoints:slots.append(max(v,slots[-1]+sep) if slots else v)
        overflow=max(0,slots[-1]-hi+.03*span)
        for (v,c,ls),y in zip(endpoints,slots):
            y-=overflow
            a.plot([4.03,4.43],[v,y],color=c,lw=.45,ls=ls)
            unit=f"{v:.0f}" if field=="peak_shared_cache_bytes" else f"{v:.2f}"
            a.text(4.48,y,unit,color=c,fontsize=5.35,va="center")
    export(f,"F5_budget")


