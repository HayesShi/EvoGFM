"""Regenerate the figures used by main.tex from the included plot inputs."""
from pathlib import Path
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent
atlas = root / "atlas"
for script in (atlas / "plot.py", root / "plot_access_column.py", root / "paired_figures.py"):
    subprocess.run([sys.executable, str(script)], check=True)
for name in ("F1_update", "F5_memory", "F5_budget", "F6_trace"):
    shutil.copyfile(atlas / (name + ".pdf"), root / "assets" / (name + ".pdf"))
subprocess.run([sys.executable, str(root / "review_figures.py")], check=True)
