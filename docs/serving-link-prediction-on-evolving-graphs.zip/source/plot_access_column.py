"""Render the four access counters at the intended 3.5-inch column width."""
from pathlib import Path
import csv
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.ticker import NullLocator
here=Path(__file__).resolve().parent
source=here/"atlas_plot_data.csv"
with source.open(encoding="utf-8-sig") as f:
    data={(r["metric"],r["graph"],r["method"]):(float(r["value"]),r["source"]=="scenario") for r in csv.DictReader(f) if r["condition"]=="0.01% / full"}
methods=["full_refresh","ours_rebuild_moments","neutronrt_adapt","head_fused","shared_lru","ours"]
colors=["#dac3e9","#d0d5dd","#b0dec9","#87c8e9","#f2d9a2","#fffdf7"]
hatches=["....","--","\\\\","","++","////"]
names=["Full refresh","Moment rescan","NeutronRT-adapt","Head-fused","Shared-LRU","Ours"]
plt.rcParams.update({"font.family":"DejaVu Serif","font.size":6.4,"axes.linewidth":.4,"hatch.linewidth":.32,"pdf.fonttype":42})
groups=[
    ("access_visits",[("Vertex visits","(a) Vertex visits"),("Edge visits","(b) Edge visits")]),
    ("access_storage",[("Feature bytes read","(c) Feature bytes"),("Statistic entries touched","(d) Statistic entries")])]
for filename,metrics in groups:
    fig,axes=plt.subplots(2,1,figsize=(1.98,1.56),sharex=True)
    fig.subplots_adjust(left=.17,right=.99,bottom=.105,top=.86,hspace=.47)
    for ax,(metric,title) in zip(axes.flat, metrics):
        for j,d in enumerate(["stack-overflow","reddit-title","wiki-talk"]):
            for i,m in enumerate(methods):
                v,sim=data[metric,d,m];x=j+(i-2.5)*.15
                ax.bar(x,v,width=.147,color=colors[i],hatch=hatches[i],edgecolor="#344351",lw=.28)
                value=f"{v:.2f}" if v>=.01 else f"{v*1e4:.1f}e-4"
                ax.annotate(value,(x,v),xytext=(0,1.2),textcoords="offset points",ha="center",va="bottom",rotation=90,fontsize=4.8)
        ax.set_title(title,loc="left",fontsize=6.35,pad=.2)
        ax.set_xticks([0,1,2],["SO","RT","WT"]);ax.set_xlim(-.51,2.49)
        if metric=="Statistic entries touched":
            ax.set_yscale("log");ax.set_ylim(6e-5,300);ax.set_yticks([.0001,.01,1]);ax.yaxis.set_minor_locator(NullLocator())
        else:ax.set_ylim(0,1.85);ax.set_yticks([0,.5,1],["0",".5","1"])
        ax.tick_params(length=1.7,width=.35,pad=.8,labelsize=5.7)
        ax.spines[["top","right"]].set_visible(False)
    fig.savefig(here/("assets/"+filename+".pdf"))
    plt.close(fig)
fig=plt.figure(figsize=(6.9,.17))
fig.legend([Patch(facecolor=c,hatch=h,edgecolor="#344351",linewidth=.35) for c,h in zip(colors,hatches)],names,ncols=6,loc="center",frameon=False,fontsize=6.4,columnspacing=1.5,handlelength=1.15,handletextpad=.3)
fig.savefig(here/"assets/access_key.pdf")
