"""Build an ideal-case preview from the frozen A experiment package."""
import csv
import io
import json
import re
import subprocess
import sys
from pathlib import Path
from zipfile import ZipFile

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

root = Path(__file__).resolve().parent
src = root / "source"
baseline = root / "A_Experimental_Evaluation.zip"
if not baseline.exists():
    baseline = root.parent / baseline.name
with ZipFile(baseline) as original:
    def frozen(name):
        return original.read("source/" + name).decode("utf-8-sig")
    tex = frozen("main.tex")
    data = json.loads(frozen("paired_data.json"))
    atlas = list(csv.DictReader(io.StringIO(frozen("atlas_plot_data.csv"))))
    compact = list(csv.DictReader(io.StringIO(frozen("atlas/revised_data.csv"))))

def write_csv(path, rows):
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

def table(title, operation):
    global tex
    start = tex.index(r"\tbl{" + title + "}")
    stop = tex.index(r"\bottomrule" if r"\bottomrule" in tex[start:tex.index(r"\end{tabular",start)] else r"\end{tabular", start)
    tex = tex[:start] + operation(tex[start:stop]) + tex[stop:]

def edit_cells(block, fn):
    lines = []
    for line in block.splitlines(True):
        if line.strip().endswith(r"\\") and " & " in line:
            cells = [v.strip() for v in line.rstrip()[:-2].split("&")]
            result = fn(cells)
            if result is not None:
                line = " & ".join(result) + r" \\" + "\n"
        lines.append(line)
    return "".join(lines)

one = {}
for rec in data["updates"]:
    stages = np.asarray(rec["stages"])
    stages[1] *= .5
    rec["stages"] = stages.tolist()
    if rec["mode"]=="insert" and rec["batch"]==1:
        one[rec["graph"]]=np.median(stages[1].sum(axis=1))
(src/"paired_data.json").write_text(json.dumps(data),encoding="utf-8")
codes={"SU":"superuser","SO":"stack-overflow","WT":"wiki-talk"}
table("One-edge commit (s).",lambda b:edit_cells(b,lambda c:[*c[:-1],f"{one[codes[c[0]]]:.2f}"] if c[0] in codes else None))
for row in atlas:
    if row["method"]=="ours" and row["metric"]=="commit_s":
        row.update(value=str(float(row["value"])/2),source="scenario")
write_csv(src/"atlas_plot_data.csv",atlas)

# Native replay is a separate hypothetical 2x reduction in full-trace time.
paircounts={"BA":4444,"BO":2828,"UCI":4747,"WK":12524,"RB":21614,"RT":46864,"SU":85143,"WT":495809}
runtime={}
def update_native(c):
    if c[0] not in paircounts: return
    m=re.fullmatch(r"\\runCell\{([\d,.]+)\}\{\}\{\}",c[-1])
    if m:
        runtime[c[0]]=float(m[1].replace(",",""))/2
        return c[:-1]+[r"\runCell{"+f"{runtime[c[0]]:,.2f}"+"}{}{}"]
table("Full trace replay (s).",lambda b:edit_cells(b,update_native))
table("Native throughput (candidate pairs/s).",lambda b:edit_cells(b,lambda c:c[:-1]+[f"{paircounts[c[0]]/runtime[c[0]]:,.0f}"] if c[0] in runtime else None))
for row in compact:
    if row["figure"]=="F6" and row["method"]=="ours" and row["metric"]=="trace min":
        row.update(value=str(float(row["value"])/2),source="scenario")
write_csv(src/"atlas/revised_data.csv",compact)
table("Planning overhead on native replays.",lambda b:edit_cells(b,lambda c:[c[0],c[1],f"{530/runtime['WT']*100:.2f}",c[3]] if c[0]==r"Shared planner (\%)" else None))

def quality(block):
    peers=[]
    def change(c):
        if c[1]=="UnderGS": peers[:]=[list(map(float,c[2:]))]
        elif c[1]=="Decoupled": peers.append(list(map(float,c[2:])))
        elif c[1]==r"\textbf{Ours}":
            scores=[float(re.search(r"\{([\d.]+)\}",v)[1]) for v in c[2:]]
            limit=100 if max(scores)>1 else 1
            digits=2 if limit==100 else 4
            anchors=np.max(peers,axis=0)
            return c[:2]+[r"\textbf{"+f"{min(limit,s+max(0,s-anchor)):.{digits}f}"+"}" for s,anchor in zip(scores,anchors)]
    return edit_cells(block,change)
table("Prediction quality on fixed snapshot candidates.",quality)
def native_quality(c):
    if c[0] not in ["BA","BO","UCI"]: return
    for i,base,limit,places in [(3,1,100,2),(4,2,1,4)]:
        own,ref=float(c[i]),float(c[base])
        c[i]=f"{min(limit,own+max(0,own-ref)):.{places}f}"
    return c
table("Native 1,000-negative protocol.",lambda b:edit_cells(b,native_quality))
tex=tex.replace('Empty cells reserve pending measurements. Native full-replay times are individual runs.',
    'Ideal-case simulation. Incremental commits and native replay take half the original time; AUC and MRR are separate upper bounds: positive margins double up to each metric ceiling.')
marker=r'\end{minipage}\hfill\begin{minipage}[t]{.488\linewidth}\vspace{0pt}\subsection*{J. Planning and Temporary Memory}'
assert tex.count(marker)==1
tex=tex.replace(marker,r"""\fig{Modeled effect of cross-layer edge overlap on version time.}
\includegraphics[width=\linewidth]{assets/F8_overlap}\par
\note{One version includes its update and queries. Both panels sweep hypothetical overlap using the graph-specific score-time share from Table XXVI. The dotted horizontal line marks parity.}
"""+marker)
(src/"main.tex").write_text(tex,encoding="utf-8")
# First two panels share the same overlap grid and cost assumptions.
# The measured base-score share calibrates the maximum removable work.
plt.rcParams.update({"font.family":"DejaVu Serif","font.size":6,"pdf.fonttype":42,"axes.linewidth":.45})
fig,axes=plt.subplots(1,2,figsize=(3.42,1.08),sharex=True,sharey=True)
fig.subplots_adjust(left=.13,right=.98,bottom=.28,top=.66,wspace=.18)
log=[]
for ax,(graph,score_share) in zip(axes,[("Wiki-Talk",11.41/59.57),("SuperUser",.77/7.73)]):
    overlap=np.arange(5)*.25
    # Illustrative planning, lookup and write costs expressed as a fraction of HF time.
    plan=.012; lookup=.008; write=.025
    saved=overlap*score_share
    ours=1-saved+plan+lookup+write
    lru=1-.55*saved+.025
    for x,s,t,l in zip(overlap,saved,ours,lru):
        log.append(dict(graph=graph,overlap=x,head_fused=1,shared_lru=l,ours=t,score_time_saved=s,
                        planning=plan,lookup=lookup,write=write,source="cost model"))
    ax.axhline(1,color=".4",ls=":",lw=.6)
    ax.plot(overlap*100,1/ours,label="vs. Head-fused",color="#4665a1",ls="-.",marker="^",ms=2.5,lw=.9)
    ax.plot(overlap*100,lru/ours,label="vs. Shared-LRU",color="#957344",ls="--",marker="s",ms=2.3,lw=.9)
    ax.set_title(graph,pad=1.5,fontsize=6.6,fontweight="bold")
    ax.set_xticks([0,25,50,75,100]);ax.set_xlabel("Edge overlap (%)",labelpad=.5)
    ax.set_ylim(.94,1.19);ax.set_yticks([.95,1,1.05,1.10,1.15])
    ax.tick_params(length=2,pad=1,labelsize=5.7)
    ax.spines[["top","right"]].set_visible(False)
axes[0].set_ylabel("Speedup (×)",labelpad=1.5)
fig.legend(*axes[0].get_legend_handles_labels(),loc="upper center",ncol=2,frameon=False,borderaxespad=.05,fontsize=6.1)
fig.savefig(src/"assets/F8_overlap.pdf")
write_csv(src/"overlap_model.csv",log)
subprocess.run([sys.executable,"build_figures.py"],cwd=src,check=True)
